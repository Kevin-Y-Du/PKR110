# 针对 SUSFS 修补内核的 KernelSU 模块 #

此模块将名为 **ksu_susfs** 和 **sus_su** 的用户空间辅助工具安装到 /data/adb/ksu 中，并提供与 SUSFS 内核通信的脚本。

此模块在内核级别为 KernelSU 提供根隐藏。

## 注意事项
- 确保您拥有一个修补了 SUSFS 的自定义内核。检查自定义内核源代码以查看它是否具有 SUSFS。
- 确保内核使用 SUSFS 1.5.2 或更高版本以实现有效隐藏。
 - Shamiko v1.2.1 或更高版本是可以接受的
- HideMyApplist 是可以接受的
- ReVanced 根模块兼容
- 如果您想使用无系统主机，建议使用 [bindhosts](https://github.com/backslashxx/bindhosts)

## 修订版 16+ 上的欺骗内核 Unname 指南
在新的 R16 版 SUSFS 中包含一个名为“欺骗内核构建”的新参数。这可能会让一些用户对它们是什么感到困惑。

 在内核版本中，它会影响此部分：
```
6.1.75-android14-11-g16c5f6cd5e9b-ab12268515
```
而在内核构建部分，则为：
```
#1 SMP PREEMPT Fri Aug 23 03:08:10 UTC 2024
```
您可以使用以下命令检查它们：
```
#这是针对内核版本的
uname -r
#这是针对内核构建的
uname -v
```

## 添加 ro.boot.vbmeta.digest 值
此模块现在将在 `/data/adb` 中有一个名为 `VerifiedBootHash` 的目录，其中包含 `VerifiedBootHash.txt`，供缺少 `ro.boot.vbmeta.digest` 值的用户使用，以防止分区被修改和启动状态检测异常。
 - 复制 Key Attestation 演示中的 VerifiedBootHash 并将其粘贴到 `/data/adb/VerifiedBootHash/VerifiedBootHash.txt`

## 积分
susfs4ksu：https://gitlab.com/simonpunk/susfs4ksu/

## 给我们买杯咖啡 ☕
### simonpunk
PayPal：`kingjeffkimo@yahoo.com.tw`
<br>BTC：`bc1qgkwvsfln02463zpjf7z6tds8xnpeykggtgk4kw`
### sidex15
PayPal：`sidex15.official@gmail.com`
<br>ETH (ERC20)：`0xa52151ebd2718a00af9e1dfcacfb30e1d3a94860`
<br>USDT  (TRC20): `TAUbxzug7cygExFunhFBiG6ntmbJwz7Skn`
 <br>USDT（ERC20）： 
 `0xa52151ebd2718a00af9e1dfcacfb30e1d3a94860`
