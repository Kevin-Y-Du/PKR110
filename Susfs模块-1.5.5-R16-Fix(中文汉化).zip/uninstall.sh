rm -f /data/adb/ksu/bin/ksu_susfs
rm -f /data/adb/ksu/bin/sus_su

